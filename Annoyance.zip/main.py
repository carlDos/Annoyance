from multiprocessing.connection import wait
from random import randint
import PySimpleGUI as sg
import time
import math
import pynput
from pynput.mouse import Button, Controller

mouse = Controller()

layout = [
    [
    sg.Text(("ready?"), key="_TEXT_")
    ],
    [
    sg.Button("yes")
    ]
    ]
window = sg.Window("Demo", layout, margins=(100,50))



while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED:
        break
    elif event == "yes":
        window["_TEXT_"].update("Starting now, Please minimize.")
        while True:
            

            VALUE = randint(0,10)
            time.sleep(VALUE)
            Ran = randint(0,1)
            if Ran == 1:
                print("R")
                mouse.press(Button.right)
                mouse.release(Button.right)
            elif Ran == 0:
                print("L")
                mouse.press(Button.left)
                mouse.release(Button.left)
            
            

window.close()