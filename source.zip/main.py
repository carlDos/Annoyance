from multiprocessing.connection import wait
from random import randint
from turtle import left, right
import PySimpleGUI as sg
import time
import math
import pynput
from pynput import mouse
from pynput.keyboard import Key, Controller
import pyautogui
keyboard = Controller()


Start = input("begin? y or n  ")

while True:

  
    if Start == "y":
        print("Activated")
        while True:
           
            VALUE = randint(0,10)
            time.sleep(VALUE)
            Ran = randint(0,4)
            if Ran == 1:
                print("R")
                pyautogui.rightClick()
            elif Ran == 0:
                pyautogui.click()
            elif Ran == 2:
                print("SPACE") 
                pyautogui.keyDown('space')
                pyautogui.keyUp('space')
            elif Ran == 3:
                print("ESC")
                pyautogui.keyDown('esc')
                pyautogui.keyUp('esc')
            elif Ran == 4:
                print("E")
                pyautogui.keyDown('e')
                pyautogui.keyUp('e')
    else:
        break
            
